select sysdate from dual;

