
select * from employees;


